#include "contact.h"
 
int main(){
    
    book books={};      //定义通讯录
    books.capacity = 0; //设置初始化通讯录当前容量为0
    int input = 0;      //模式变量
    int flag = 0;       //退出程序标志
    while (!flag)
    {
        system("cls");  //清空屏幕
        menu();         //显示菜单
        cout<<"请输入模式(数字):>"<<endl;
        cin>>input;
        switch (input)
        {
            case 1://添加联系人
                    add_contact(&books);
                break;
            case 2://展示联系人
                    show_contact(&books);
                break;
            case 3://删除联系人
                    delet_contact(&books);
                break;
            case 4://查找联系人
                    find_contact(&books);
                break;
            case 5://更改联系人
                    change_contact(&books);
                break;
            case 6://清空联系人
                clear_contact(&books);
                break;
                
            case 7://退出通讯录
                flag = exit_contact(&books);
                break;
    
            default:
                cout<<"error!"<<endl;
                break;
        }
    }
    
 
}