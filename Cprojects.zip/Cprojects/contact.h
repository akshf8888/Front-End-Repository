#include <iostream>
#include <string>
#include <ctime>
#define MAX 100     //通讯录大小
using namespace std;
 
//联系人结构体
struct contact
{
    string name;    //姓名
    string sex;     //性别
    string age;     //年龄
    string phone;   //电话
    string address; //住址
};
 
//通讯录结构体
struct book
{
    int capacity;           //通讯录当前已有容量
    contact contacts[MAX];  //通讯设置录最大容量
 
};
 
//菜单
void menu();
 
//添加联系人
void add_contact(book* books);
 
//显示联系人
void show_contact(book* books);
 
//删除联系人
void delet_contact(book* books);
 
//查找联系人
void find_contact(book* books);
 
//更改联系人
void change_contact(book* books);
 
//清空联系人
void clear_contact(book* books);
 
//退出通讯录
int exit_contact(book* books);