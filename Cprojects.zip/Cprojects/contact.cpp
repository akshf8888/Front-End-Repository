#include "contact.h"
 
 
int find_name(book* books,string target_name)
//                  通讯录          目标名字
{
    //通过联系人名字找到联系人在通讯录中的下标
    for(int i=0;i<books->capacity;i++)
    {
        if(target_name == books->contacts[i].name)
            return i;
    }
    return -1;
 
}
 
int jude(int mode)
//          当前模式
{
    //通过输入的模式确定输出语句,来判断是否误输入
    string mode_list[] = {"添加","删除","查找","修改","清空"};
    char inp;
    cout<<"确定要"<<mode_list[mode]<<"联系人吗(y/n):>"<<endl;
    cin>>inp;
    if(inp == 'n')
        return 1;
    else
        return 0;
}
 
void menu()
{
    //展示菜单
    cout<<"****************************"<<endl;
    cout<<"******      通讯录     ******"<<endl;
    cout<<"******   1.增加联系人   ******"<<endl;
    cout<<"******   2.显示联系人   ******"<<endl;
    cout<<"******   3.删除联系人   ******"<<endl;
    cout<<"******   4.查找联系人   ******"<<endl;
    cout<<"******   5.修改联系人   ******"<<endl;
    cout<<"******   6.清空联系人   ******"<<endl;
    cout<<"******   7.退出通讯录   ******"<<endl;
    cout<<"****************************"<<endl;
}
 
void add_contact(book* books)
{
    //判断误输入
    if(jude(0))return;
    
    cout<<"请输入姓名:>"<<endl;
    cin>>books->contacts[books->capacity].name;
 
    cout<<"请选择性别(男/女):>"<<endl;
    cin>>books->contacts[books->capacity].sex;
 
    cout<<"请输入年龄:>"<<endl;
    cin>>books->contacts[books->capacity].age;
 
    cout<<"请输入电话:>"<<endl;
    cin>>books->contacts[books->capacity].phone;
 
    cout<<"请输入住址:>"<<endl;
    cin>>books->contacts[books->capacity].address;
 
    //容量递增
    books->capacity += 1;
 
    cout<<"添加成功！"<<endl;
    system("pause");
    
}
 
void show_contact(book* books)
{
    cout<<"姓名\t性别\t年龄\t\t电话\t\t住址"<<endl;
    for(int i =0;i<books->capacity;i++)
    {
        cout<<books->contacts[i].name<<"\t"\
            <<books->contacts[i].sex<<"\t"\
            <<books->contacts[i].age<<"\t\t"\
            <<books->contacts[i].phone<<"\t"\
            <<books->contacts[i].address<<endl;
    }
    system("pause");
}
 
 
 
void delet_contact(book* books)
{
    //误输入判断
    if(jude(1))return;
    
    string select_name;
    cout<<"请输入要删除的联系人姓名:>"<<endl;
    cin>>select_name;
    
    int index = find_name(books,select_name);
 
 
    if(index == -1)     //判断是否存在该联系人
    {
        cout<<"不存在该联系人!!"<<endl;
        system("pause");
        return ;
    }
 
    //从联系人的后一位开始覆盖
    for(int i = index ; i < books -> capacity;i++)
    {
        // 当前联系人contacts[i]  <- 下一位联系人contacts[i+1]
        books->contacts[i] = books->contacts[i+1];
    }
    books->capacity-=1;
    cout<<"删除成功！"<<endl;
    system("pause");
    
 
    
    
}
 
void find_contact(book* books)
{
    string select_name;
    cout<<"请输入要查找联系人姓名:>"<<endl;
    cin>>select_name;
 
    int index = find_name(books,select_name);
    if(index == -1)
    {
        cout<<"不存在该联系人!!"<<endl;
        system("pause");
        return ;
    }
 
    cout<<"姓名\t性别\t年龄\t\t电话\t\t住址"<<endl;
    cout<<books->contacts[index].name<<"\t"\
        <<books->contacts[index].sex<<"\t"\
        <<books->contacts[index].age<<"\t\t"\
        <<books->contacts[index].phone<<"\t"\
        <<books->contacts[index].address<<endl;
    system("pause");
    return;
 
}
 
void change_contact(book* books)
{
    
    if(jude(3)) return ;
 
    string select_name;
    cout<<"请输入要修改的联系人姓名:>"<<endl;
    cin>>select_name;
 
    int index = find_name(books,select_name);
    if(index == -1)
    {
        cout<<"不存在该联系人!!"<<endl;
        system("pause");
        return ;
    }
 
    int mode=1;
    while(mode)
    {
        
        string attribute,modified_attribute;
        cout<<"请输入要修改的属性(姓名/性别/年龄/电话/住址):>"<<endl;
        cin>>attribute;
 
        cout<<"请输入修改后的值:>"<<endl;
        cin>>modified_attribute;
        if(attribute == "姓名" || attribute == "1")
        {
            books->contacts[index].name = modified_attribute;
        }
        if(attribute == "性别" || attribute == "2")
        {
            books->contacts[index].sex = modified_attribute;
        }
        if(attribute == "年龄" || attribute == "3")
        {
            books->contacts[index].age = modified_attribute;
        }
        if(attribute == "电话" || attribute == "4")
        {
            books->contacts[index].phone = modified_attribute;
        }
        if(attribute == "住址" || attribute == "5")
        {
            books->contacts[index].address = modified_attribute;
        }
        cout<<"是否要继续修改(1/0):>"<<endl;
        cin>>mode;
 
 
    }
 
 
 
}
 
void clear_contact(book* books)
{
    if(jude(4))return;
    books->capacity = 0;
    return ;
}
 
int exit_contact(book* books)
{
    char jude;
    cout<<"确定要退出通讯录吗(y/n):>"<<endl;
    cin>>jude;
    if(jude == 'n')
        return 0;
    return 1;
}
 
